package com.company.onlinestore.order.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class CustmerMapper implements RowMapper<Custmer>
{

	@Override
	public Custmer mapRow(ResultSet rs, int row) throws SQLException {
		
		Custmer custmer=new Custmer();
		custmer.setId(rs.getInt("id"));
		custmer.setName(rs.getString("name"));
		return custmer;
	}

}
