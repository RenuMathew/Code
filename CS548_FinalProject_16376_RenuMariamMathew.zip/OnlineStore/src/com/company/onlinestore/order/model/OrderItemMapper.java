package com.company.onlinestore.order.model;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

public class OrderItemMapper implements RowMapper<OrderItem>{

	@Override
	public OrderItem mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		OrderItem orderItem=new OrderItem();
		orderItem.setOrderId(rs.getInt("order_id"));
		orderItem.setProductId(rs.getInt("product_Id"));
		orderItem.setQuantity(rs.getInt("quantity"));
		orderItem.setTotalAmt(rs.getDouble("totalAmt"));
		return orderItem;
	}

}
