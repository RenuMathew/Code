package com.company.onlinestore.order.model;

public class Order 
{

	private Integer id;
	
	private Integer custmerId;
	
	private Boolean isProccessed;

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the custmerId
	 */
	public Integer getCustmerId() {
		return custmerId;
	}

	/**
	 * @param custmerId the custmerId to set
	 */
	public void setCustmerId(Integer custmerId) {
		this.custmerId = custmerId;
	}

	/**
	 * @return the isProccessed
	 */
	public Boolean getIsProccessed() {
		return isProccessed;
	}

	/**
	 * @param isProccessed the isProccessed to set
	 */
	public void setIsProccessed(Boolean isProccessed) {
		this.isProccessed = isProccessed;
	}
	
	
}
