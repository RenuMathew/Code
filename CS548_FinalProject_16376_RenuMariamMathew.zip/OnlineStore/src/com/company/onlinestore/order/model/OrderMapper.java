package com.company.onlinestore.order.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class OrderMapper implements RowMapper<Order>
{

	@Override
	public Order mapRow(ResultSet rs, int row) throws SQLException 
	{
		Order order=new Order();
		order.setCustmerId(rs.getInt("custmer_id"));
		order.setId(rs.getInt("id"));
		order.setIsProccessed(rs.getBoolean("is_proccessed"));
		return order;
	} 

}
