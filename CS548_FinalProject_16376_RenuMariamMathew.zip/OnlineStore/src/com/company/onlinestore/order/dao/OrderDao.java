package com.company.onlinestore.order.dao;

import java.util.List;

import com.company.onlinestore.order.model.Custmer;
import com.company.onlinestore.order.model.Order;
import com.company.onlinestore.order.model.OrderItem;

public interface OrderDao 
{
	public Long saveOrderItem(OrderItem orderItem);
	
	public Custmer getCustmerByName(String custmerName);
	
	public Long saveOrderInfo(Order order);
	
	public Integer updateOrder(Integer orderId);
	
	public Integer deleteOrderItem(Integer orderId);
	
	public Integer deleteOrder(Integer orderId);
	
	public List<Order> custmerOrders(Integer custmerId);
	
	public List<OrderItem> custmerOrderItems(Integer orderId);
	
	public List<OrderItem> getAllOrderItems();
}
