package com.company.onlinestore.order.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Service;

import com.company.onlinestore.order.model.Custmer;
import com.company.onlinestore.order.model.CustmerMapper;
import com.company.onlinestore.order.model.Order;
import com.company.onlinestore.order.model.OrderItem;
import com.company.onlinestore.order.model.OrderItemMapper;
import com.company.onlinestore.order.model.OrderMapper;

@Service
public class OrderDaoImpl implements OrderDao
{
	@Autowired
	private JdbcTemplate  jdbcTemplate;
	
	
	public Long saveOrderItem(final OrderItem orderItem)
	{
		Long key=0l;
		final String sql="INSERT INTO ORDER_ITEM(PRODUCT_ID,QUANTITY,TOTALAMT,ORDER_ID) VALUES(?,?,?,?)";
		KeyHolder holder = new GeneratedKeyHolder();
		jdbcTemplate.update(new PreparedStatementCreator() {           

		                @Override
		                public PreparedStatement createPreparedStatement(Connection connection)
		                        throws SQLException {
		                    PreparedStatement ps = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
		                    ps.setInt(1, orderItem.getProductId());
		                    ps.setInt(2, orderItem.getQuantity());
		                    ps.setDouble(3, orderItem.getTotalAmt());
		                    ps.setInt(4, orderItem.getOrderId());
		                    return ps;
		                }
		            }, holder);
		

		return key;
	}

	public Custmer getCustmerByName(String cutmerName){
		Custmer custmer=null;
		try {
			custmer= jdbcTemplate.queryForObject("SELECT * FROM CUSTMER WHERE name =? ",
					new Object[] { cutmerName }, new CustmerMapper());
		} catch (EmptyResultDataAccessException e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		}catch (Exception e) {
			// TODO: handle exception
			throw e;
		}
		
		return custmer;
	}
	
	public Long saveOrderInfo(final Order order)
	{
		Long key=0l;
		final String sql="INSERT INTO CUSTMER_ORDER(CUSTMER_ID,IS_PROCCESSED) VALUES(?,?)";
		KeyHolder holder = new GeneratedKeyHolder();
		jdbcTemplate.update(new PreparedStatementCreator() {           

		                @Override
		                public PreparedStatement createPreparedStatement(Connection connection)
		                        throws SQLException {
		                    PreparedStatement ps = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
		                    
		                    ps.setInt(1, order.getCustmerId());
		                    ps.setBoolean(2, order.getIsProccessed());
		                    return ps;
		                }
		            }, holder);
		
		key=holder.getKey().longValue();
		return key;
	}
	
	public Integer updateOrder(Integer orderId){
		int stat=jdbcTemplate.update("UPDATE CUSTMER_ORDER SET IS_PROCCESSED =1 WHERE ID=?",
		new Object[]{orderId});
		return stat;
	}
	
	public Integer deleteOrderItem(Integer orderId){
		int stat=jdbcTemplate.update("DELETE FROM ORDER_ITEM WHERE ORDER_ID=?",
		new Object[]{orderId});
		return stat;
	}
	
	public Integer deleteOrder(Integer orderId){
		int stat=jdbcTemplate.update("DELETE FROM CUSTMER_ORDER WHERE ID=?",
		new Object[]{orderId});
		return stat;
	}

	@Override
	public List<Order> custmerOrders(Integer custmerId) {
		List<Order> orders=null;
		orders= jdbcTemplate.query("SELECT * FROM CUSTMER_ORDER WHERE CUSTMER_ID =? ",
				new Object[] { custmerId}, new OrderMapper());
		return orders;
	}

	@Override
	public List<OrderItem> custmerOrderItems(Integer orderId) {
		List<OrderItem> orders=null;
		orders= jdbcTemplate.query("SELECT * FROM ORDER_ITEM WHERE ORDER_ID =? ",
				new Object[] { orderId}, new OrderItemMapper());
		return orders;
	}

	@Override
	public List<OrderItem> getAllOrderItems() {
		List<OrderItem> orders=null;
		orders= jdbcTemplate.query("select oi.order_id, prod.id, prod.name, oi.quantity, oi.totalAmt from order_item oi, product prod where oi.product_id is not null and oi.product_id = prod.id",
				new Object[] { }, new OrderItemMapper());
		return orders;
	}
}
