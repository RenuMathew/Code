package com.company.onlinestore.order.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.company.onlinestore.exception.InsufficientQuantityException;
import com.company.onlinestore.order.dao.OrderDao;
import com.company.onlinestore.order.model.Custmer;
import com.company.onlinestore.order.model.Order;
import com.company.onlinestore.order.model.OrderItem;
import com.company.onlinestore.order.model.OrderObject;
import com.company.onlinestore.productmanagement.dao.ProductManagementDao;
import com.company.onlinestore.productmanagement.model.Inventory;
import com.company.onlinestore.productmanagement.model.Product;

@Service
public class OrderServiceImpl implements OrderService
{
	
	@Autowired
	private ProductManagementDao productManagementDao;
	
	@Autowired
	private OrderDao orderDao;
	
	@Autowired
	private PlatformTransactionManager txnManager;

	public Long createOrder(String custmerName,String productName,Integer orderQty)throws Exception
	{
		
		//check product available in inventory 
		Product product=productManagementDao.getProductByName(productName);
		Custmer custmer=orderDao.getCustmerByName(custmerName);
		TransactionStatus transactionStatus=txnManager.getTransaction(
				new DefaultTransactionDefinition());
		Long orderId=null;
		try {
			if(product!=null&&custmer!=null)
			{
				Inventory inventory=productManagementDao.getInventory(product.getId());
				
				int actuvalQty=inventory.getQuantity();
				if(orderQty<=actuvalQty)
				{
					
					Order order=new Order();
					order.setCustmerId(custmer.getId());
					order.setIsProccessed(false);
					
					orderId=orderDao.saveOrderInfo(order);
					
					OrderItem orderItem=new OrderItem();
					orderItem.setProductId(product.getId());
					orderItem.setQuantity(orderQty);
					orderItem.setOrderId(orderId.intValue());
					
					Double price=product.getPrice();
					Double totalAmt=price*orderQty;
					
					
					orderItem.setTotalAmt(totalAmt);
					//save order
					orderDao.saveOrderItem(orderItem);
					
					//After order products update inventory product quantity.
					int remainingQty=actuvalQty-orderQty;
					inventory.setQuantity(remainingQty);
					
					productManagementDao.updateInvProQty(inventory);
					txnManager.commit(transactionStatus);
				}
				else
				{
					throw new InsufficientQuantityException("Order quantity is execceded");
				}
			}
			else
			{
				throw new Exception("In Valid input");
			}
		} catch (Exception e) {
			// TODO: handle exception
			txnManager.rollback(transactionStatus);
			throw e;
		}
		return orderId;
	}
	
	public Integer cancleOrder(Integer orderId)throws Exception
	{
		TransactionStatus transactionStatus=txnManager.getTransaction(
				new DefaultTransactionDefinition());
		int stat=0;
		try{
			orderDao.deleteOrderItem(orderId);
			stat=orderDao.deleteOrder(orderId);
		txnManager.commit(transactionStatus);
		}catch(Exception e){
			txnManager.rollback(transactionStatus);
			throw e;
		}
		return stat;
	}
	
	public List<OrderObject> custmerOrderList(String custmerName)
	{
		Custmer custmer=orderDao.getCustmerByName(custmerName);
		
		List<Order> orders=orderDao.custmerOrders(custmer.getId());
		List<OrderObject> orderObjects=new ArrayList<OrderObject>();
		for(Order order:orders)
		{
			List<OrderItem> orderItems=orderDao.custmerOrderItems(order.getId());	
			
			for(OrderItem orderItem:orderItems)
			{
				Product product=productManagementDao.getProductById(orderItem.getProductId());

				OrderObject orderObject=new OrderObject();
				orderObject.setOrderItem(orderItem);
				orderObject.setProduct(product);
				orderObjects.add(orderObject);
			}
		}
		return orderObjects;
	}
}