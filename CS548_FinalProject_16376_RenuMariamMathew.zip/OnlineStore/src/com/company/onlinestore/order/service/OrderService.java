package com.company.onlinestore.order.service;

import java.util.List;

import com.company.onlinestore.order.model.OrderObject;

public interface OrderService {

	public Long createOrder(String custmerName,String productName,Integer orderQty)throws Exception;
	
	public Integer cancleOrder(Integer orderId)throws Exception;
	
	public List<OrderObject> custmerOrderList(String custmerName);
}
