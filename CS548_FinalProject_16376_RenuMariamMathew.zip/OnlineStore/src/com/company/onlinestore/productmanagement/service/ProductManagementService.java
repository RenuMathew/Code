package com.company.onlinestore.productmanagement.service;

import com.company.onlinestore.productmanagement.model.Product;

public interface ProductManagementService 
{

	public void saveProduct(Product product, int productQnt);
}
