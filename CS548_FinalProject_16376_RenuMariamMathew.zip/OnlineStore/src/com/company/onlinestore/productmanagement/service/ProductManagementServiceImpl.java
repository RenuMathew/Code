package com.company.onlinestore.productmanagement.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.company.onlinestore.productmanagement.dao.ProductManagementDao;
import com.company.onlinestore.productmanagement.model.Inventory;
import com.company.onlinestore.productmanagement.model.Product;

@Service
public class ProductManagementServiceImpl implements ProductManagementService
{
	@Autowired
	private ProductManagementDao productManagementDao;

	@Autowired
	private PlatformTransactionManager txnManager;
	
	public void saveProduct(Product product, int productQnt)
	{
		Product productTemp = productManagementDao.getProductByName(product.getName());
		TransactionStatus txnStatus=txnManager.getTransaction(new DefaultTransactionDefinition());
		
		// if product is not there then we will get null otherwise we will get Product object
		try {
			if (productTemp == null) {
				
				
				Long key=productManagementDao.saveProduct(product);
				if(key!=0&&key!=null)
				{
					Inventory inventory = new Inventory();
					inventory.setProductId(key.intValue());
					inventory.setQuantity(productQnt);
					productManagementDao.saveInventory(inventory);
				}
				else
				{
					txnManager.rollback(txnStatus);
				}
				
				
			} else {
				// product and inventory are already existed
				Inventory inventory = productManagementDao.getInventory(productTemp.getId()); 
				inventory.setQuantity(inventory.getQuantity()+productQnt);
				productManagementDao.updateInvProQty(inventory);
			}
			txnManager.commit(txnStatus);
		} catch (Exception e) {
			e.printStackTrace();
			//txnManager.rollback(txnStatus);
			// TODO: handle exception
		}
		
	}
	

}
