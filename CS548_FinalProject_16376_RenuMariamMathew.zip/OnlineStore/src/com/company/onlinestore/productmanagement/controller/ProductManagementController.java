package com.company.onlinestore.productmanagement.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.company.onlinestore.productmanagement.dao.ProductManagementDao;
import com.company.onlinestore.productmanagement.model.Inventory;
import com.company.onlinestore.productmanagement.model.Product;
import com.company.onlinestore.productmanagement.service.ProductManagementService;

@Controller
public class ProductManagementController {
	
	//@Autowired
	//private AbstractApplicationContext context;
	
	@Autowired
	private ProductManagementDao productManagementDao;
	
	@Autowired
	private ProductManagementService prodService;

	@RequestMapping(value = "/")
	public String cont() {
		return "home";
	}
	
	@RequestMapping("/home")
	public ModelAndView home(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("home", "message", "Employee Added");
	}

	@RequestMapping("/product")
	public ModelAndView product(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		List<Product> productList = productManagementDao.getAllProducts();
		for(Product product:productList)
		{
			Inventory inventory=productManagementDao.getInventory(product.getId());
			product.setQty(inventory.getQuantity());
		}
		
		return new ModelAndView("product", "message", productList);
	}

	@RequestMapping("/order")
	public ModelAndView order(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("order", "message", "Employee Added");
	}

	@RequestMapping("/addProduct")
	public String addProduct(HttpServletRequest request, HttpServletResponse response,Model model) throws Exception {
		//System.out.println(request.getParameter("message")+"----------------------------");
		model.addAttribute("product",new Product() );
		return "addProduct";//new ModelAndView("addProduct", "message", request.getParameter("message"));
	}

	@RequestMapping(value = "/saveProduct", method = RequestMethod.POST)
	public ModelAndView saveProduct(@ModelAttribute()Product product,HttpServletRequest request, HttpServletResponse response) throws Exception {
		// Save product
		
		//Need to check the product is already existed or not
		prodService.saveProduct(product, product.getQty());	
		return new ModelAndView("redirect:product", "message", null);
	}

	@RequestMapping(value = "checkProduct",method=RequestMethod.GET,produces="application/json")
	@ResponseBody
	public Map<Object, Object> checkProduct(HttpServletRequest  request)
	{
		Map< Object, Object> map=new HashMap<>();
		
		try
		{
			Product product=productManagementDao.getProductByName(request.getParameter("prodName"));
			if(product==null)
				map.put("status", "NOT_EXIST");
			else
				map.put("status", "EXIST");
			
		}catch(Exception e)
		{
			map.put("status", "NOT_EXIST");
		}
		
		return map;
	}
	
	@RequestMapping(value = "/deleteProduct")
	public ModelAndView deleteProduct(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		return new ModelAndView("redirect:product", "message", null);
	}
	
	@RequestMapping(value="/edit/product/{id}")
	public String editProduct(@PathVariable("id")Integer id,Model model)
	{
		Product product=productManagementDao.getProductById(id);
		Inventory inventory=productManagementDao.getInventory(id);
		product.setQty(inventory.getQuantity());
		model.addAttribute("product",product );
		return "addProduct";
	}
	
	@RequestMapping("custmers")
	public String custmers(Model model)
	{
		
		model.addAttribute("custmers", productManagementDao.getCustmers());
		return "custmers";
	}
}
