package com.company.onlinestore.productmanagement.controller;

import java.util.Iterator;
import java.util.List;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.company.onlinestore.order.dao.OrderDao;
import com.company.onlinestore.order.model.OrderItem;
import com.company.onlinestore.productmanagement.dao.ProductManagementDao;
import com.company.onlinestore.productmanagement.model.Product;

public class Test {

	public static void main(String[] args) {
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		ProductManagementDao productManagementDao = (ProductManagementDao) context.getBean("productManagementDao");
		OrderDao orderDao = (OrderDao) context.getBean("orderDao");
		
		//Get all products
		/*List<Product> productList = productManagementDao.getAllProducts();
		Iterator iterator = productList.iterator();
		while(iterator.hasNext()){
			Product prod = (Product) iterator.next();
			System.out.println(prod.getId()+"  "+prod.getName()+"  "+prod.getPrice());
		}*/
		
		//Get all records
		/*List<OrderItem> orderItemsList = orderDao.getAllOrderItems();
		Iterator ordersIterator = orderItemsList.iterator();
		while(ordersIterator.hasNext()){
			OrderItem orderItem = (OrderItem) ordersIterator.next();
			System.out.println(orderItem.getOrderId()+"  "+orderItem.getProductId()+"  "+orderItem.getQuantity()+"	"+orderItem.getTotalAmt());
		}*/
		
		//Check the product is existed or not;
		/*Product temp = productManagementDao.getProductByName("product1lskdjf");
		System.out.println(temp);*/
	}

}
