package com.company.onlinestore.productmanagement.model;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

public class InventoryMapper implements RowMapper<Inventory>{

	@Override
	public Inventory mapRow(ResultSet rs, int rowNum) throws SQLException {
		Inventory inventory = new Inventory();
		inventory.setId(rs.getInt("id"));
		inventory.setProductId(rs.getInt("product_id"));
		inventory.setQuantity(rs.getInt("quantity"));
		return inventory;
	}

}
