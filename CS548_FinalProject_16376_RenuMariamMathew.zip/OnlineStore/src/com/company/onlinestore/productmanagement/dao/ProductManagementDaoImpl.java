package com.company.onlinestore.productmanagement.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Service;

import com.company.onlinestore.order.model.Custmer;
import com.company.onlinestore.productmanagement.model.Inventory;
import com.company.onlinestore.productmanagement.model.InventoryMapper;
import com.company.onlinestore.productmanagement.model.Product;
import com.company.onlinestore.productmanagement.model.ProductMapper;

@Service
public class ProductManagementDaoImpl implements ProductManagementDao
{
	@Autowired
	private JdbcTemplate  jdbcTemplate;
		
	public Long saveProduct(final Product product)
	{
		Long key=0l;
		try {
			/*int stat=jdbcTemplate.update("INSERT INTO PRODUCT(NAME,PRICE) VALUES(?,?)",
					new Object[]{product.getName(),product.getPrice( )});
			System.out.println(stat);*/
			final String sql="INSERT INTO PRODUCT(NAME,PRICE) VALUES(?,?)";
			KeyHolder holder = new GeneratedKeyHolder();
			jdbcTemplate.update(new PreparedStatementCreator() {           

			                @Override
			                public PreparedStatement createPreparedStatement(Connection connection)
			                        throws SQLException {
			                    PreparedStatement ps = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
			                    ps.setString(1, product.getName());
			                    ps.setDouble(2, product.getPrice());
			                    return ps;
			                }
			            }, holder);
			
			key=holder.getKey().longValue();
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
		return key;
	}

	public Long saveInventory(final Inventory inventory)
	{
		Long key=0l;
		final String sql="INSERT INTO INVENTORY(PRODUCT_ID,QUANTITY) VALUES(?,?)";
		KeyHolder holder = new GeneratedKeyHolder();
		jdbcTemplate.update(new PreparedStatementCreator() {           

		                @Override
		                public PreparedStatement createPreparedStatement(Connection connection)
		                        throws SQLException {
		                    PreparedStatement ps = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
		                    ps.setInt(1, inventory.getProductId());
		                    ps.setDouble(2, inventory.getQuantity());
		                    return ps;
		                }
		            }, holder);
		key=holder.getKey().longValue();
		return key;
	}
	
	/**
	 * update inventory
	 */
	public Integer updateInvProQty(Inventory inventory)
	{
		int stat=jdbcTemplate.update("UPDATE INVENTORY SET quantity=? WHERE id=?",
				new Object[]{inventory.getQuantity(),inventory.getId()});
		return stat;
	}
	
	public Product getProductByName(String prodName){
		Product product =null;
		try {
			product= jdbcTemplate.queryForObject("SELECT * FROM product WHERE name =? ",
					new Object[] { prodName }, new ProductMapper());
		} catch (EmptyResultDataAccessException e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		}catch (Exception e) {
			// TODO: handle exception
			throw e;
		}
		
		return product;
	}
	
	public Product getProductById(Integer prodId){
		Product product =null;
		try {
			product= jdbcTemplate.queryForObject("SELECT * FROM product WHERE ID =? ",
					new Object[] { prodId }, new ProductMapper());
		} catch (EmptyResultDataAccessException e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		}catch (Exception e) {
			// TODO: handle exception
			throw e;
		}
		
		return product;
	}
	
	public void deleteProduct(Integer prodId){
		try {
			int rows = jdbcTemplate.update("DELETE FROM product WHERE ID =? ",	new Object[] { prodId });
			 System.out.println(rows + " row(s) deleted.");
		} catch (EmptyResultDataAccessException e) {
			// TODO: handle exception
			e.printStackTrace();
		}catch (Exception e) {
			// TODO: handle exception
			throw e;
		}
	}
	
	public void editProduct(Product prodId){
		try {
			int rows = jdbcTemplate.update("update product set name=?, price=? where id = ?",
					new Object[] { prodId.getName(), prodId.getPrice(), prodId.getId() });
			 System.out.println(rows + " row(s) deleted.");
		} catch (EmptyResultDataAccessException e) {
			// TODO: handle exception
			e.printStackTrace();
		}catch (Exception e) {
			// TODO: handle exception
			throw e;
		}
	}
	public List<Product> getAllProducts(){
		List<Product> productList =new ArrayList<Product>();
		try {
			productList= jdbcTemplate.query("SELECT * FROM product", new ProductMapper());
			//List<Map<String,Object>> map= jdbcTemplate.queryForList("SELECT * FROM product",new BeanPropertyRowMapper(Product.class));
			//ListIterator<Map<String, Object>> iterator = map.listIterator();
			/*while(iterator.hasNext())
			{
				Product product = (Product) iterator.next().get(0);
				productList.add(product);
			}*/
		} catch (EmptyResultDataAccessException e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		}catch (Exception e) {
			// TODO: handle exception
			throw e;
		}
		
		return productList;
	}
	
	public Inventory getInventory(Integer id){
		Inventory inventory =null;
		try{	
			inventory = jdbcTemplate.queryForObject(
					"SELECT * FROM product_mnagement.inventory WHERE product_id =?", new Object[] { id}, new InventoryMapper());
			
		} catch (EmptyResultDataAccessException e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		}catch (Exception e) {
			// TODO: handle exception
			throw e;
		}
		return inventory;
	}
	

	@Override
	public Integer getInventoryIdMax() {
		Inventory inventory = jdbcTemplate.queryForObject(
				"select * from product_mnagement.inventory A where A.id = (select max(id) from product_mnagement.inventory)",
				new Object[] {}, new InventoryMapper());
		return inventory.getId();
	}

	public List<Custmer> getCustmers()
	{
		List<Map<String, Object>> maps=jdbcTemplate.queryForList("select * from custmer");
		List<Custmer> custmers=new ArrayList<>();
		
		for(Map<String, Object> map: maps){
			Custmer custmer=new Custmer();
			custmer.setId((Integer) map.get("id"));
			custmer.setName((String) map.get("name"));
			custmers.add(custmer);
		}
		
		return custmers;
	}
}
