package com.company.onlinestore.productmanagement.dao;

import java.util.List;

import com.company.onlinestore.order.model.Custmer;
import com.company.onlinestore.productmanagement.model.Inventory;
import com.company.onlinestore.productmanagement.model.Product;

/**
 *Products store information process dao
 */
public interface ProductManagementDao 
{
	
	public Long saveProduct(Product product);
	
	public Integer updateInvProQty(Inventory inventory);
	
	public Product getProductByName(String product);
	
	public Product getProductById(Integer prodId);
	
	public Inventory getInventory(Integer prodId);
	
	public Integer getInventoryIdMax();
	
	public Long saveInventory(Inventory inventory);
	
	public List<Product> getAllProducts();
	
	public void deleteProduct(Integer prodId);
	
	public void editProduct(Product prod);
	
	public List<Custmer> getCustmers();
}
