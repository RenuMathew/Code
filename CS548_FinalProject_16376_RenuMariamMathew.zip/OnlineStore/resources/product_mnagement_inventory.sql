

DROP TABLE IF EXISTS `inventory`;

CREATE TABLE `inventory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_inventory_pro_id` (`product_id`),
  CONSTRAINT `fk_inventory_pro_id` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

LOCK TABLES `inventory` WRITE;

INSERT INTO `inventory` (`id`, `product_id`, `quantity`) VALUES (1,39,6),(2,40,1),(3,11,12);

UNLOCK TABLES;
