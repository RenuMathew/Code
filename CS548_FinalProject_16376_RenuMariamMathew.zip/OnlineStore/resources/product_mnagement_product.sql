

DROP TABLE IF EXISTS `product`;

CREATE TABLE `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;

LOCK TABLES `product` WRITE;

INSERT INTO `product` (`id`, `name`, `price`) VALUES (11,'product1',13),(39,'produ1',23),(40,'p',1);

UNLOCK TABLES;
