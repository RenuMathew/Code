
DROP TABLE IF EXISTS `custmer`;

CREATE TABLE `custmer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

LOCK TABLES `custmer` WRITE;

INSERT INTO `custmer` (`id`, `name`) VALUES (1,'custmer1'),(2,'custmer2');

UNLOCK TABLES;
