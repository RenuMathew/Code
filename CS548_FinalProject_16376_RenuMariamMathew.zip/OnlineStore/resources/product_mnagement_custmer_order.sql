
DROP TABLE IF EXISTS `custmer_order`;

CREATE TABLE `custmer_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `custmer_id` int(11) DEFAULT NULL,
  `is_proccessed` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_order_cust_id` (`custmer_id`),
  CONSTRAINT `fk_order_cust_id` FOREIGN KEY (`custmer_id`) REFERENCES `custmer` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

LOCK TABLES `custmer_order` WRITE;

INSERT INTO `custmer_order` (`id`, `custmer_id`, `is_proccessed`) VALUES (9,1,0);

UNLOCK TABLES;
