
DROP TABLE IF EXISTS `order_item`;

CREATE TABLE `order_item` (
  `order_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `totalAmt` int(11) DEFAULT NULL,
  KEY `fk_order_item_order_id` (`order_id`),
  KEY `fk_order_item_pro_id` (`product_id`),
  CONSTRAINT `fk_order_item_order_id` FOREIGN KEY (`order_id`) REFERENCES `custmer_order` (`id`),
  CONSTRAINT `fk_order_item_pro_id` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `order_item` WRITE;

INSERT INTO `order_item` (`order_id`, `product_id`, `quantity`, `totalAmt`) VALUES (9,11,3,39);

UNLOCK TABLES;



