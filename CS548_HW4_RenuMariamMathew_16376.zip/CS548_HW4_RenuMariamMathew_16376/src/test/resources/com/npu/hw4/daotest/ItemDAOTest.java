package com.npu.hw4.daotest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.npu.hw4.dao.ItemDAO;
import com.npu.hw4.domain.Item;

@ContextConfiguration("classpath:serviceTest.xml")
@RunWith(SpringJUnit4ClassRunner.class)
public class ItemDAOTest {
	
	@Autowired
	@Qualifier("itemDao")
	private ItemDAO itemDAO;
	
	
	@Test
	public void testItemsCount() {
		List<Item> allItems = itemDAO.getAllItems();
		assertEquals(allItems.size(), 2);
	}
	
	
	@Test
	public void testItem() {
		Item item = itemDAO.getItemByName("Algorithms");
		assertNotNull(item);
	}
	
	
	@Test
	public void testItemUpdate() {
		Item item = itemDAO.getItemByName("Algorithms");
		item.setQuantity(20);
		itemDAO.updateItem(item);
		Item itemByName = itemDAO.getItemByName("Algorithms");
		assertEquals(itemByName.getQuantity(),20);
	}
	
}
