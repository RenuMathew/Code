package com.npu.hw4.daotest;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.npu.hw4.dao.LoginDAO;
import com.npu.hw4.domain.Login;


@ContextConfiguration("classpath:serviceTest.xml")
@RunWith(SpringJUnit4ClassRunner.class)
public class LoginDAOTest {
	@Autowired
	@Qualifier("loginDao")
	private LoginDAO loginDAO;
	
	
	@Test
	public void testUsersCount() {
		List<Login> allUsers = loginDAO.getAllUsers();
		assertEquals(allUsers.size(), 2);
	}
	

	@Test
	public void testUserPassword() {
		Login login = loginDAO.getLogin("renu");
		assertEquals(login.getPassword(), "renu123");
	}
	
	
	@Test
	public void testLoginUpdate() {
		Login login = loginDAO.getLogin("renu");
		login.setPassword("renuChanged");
		loginDAO.updateLogin(login);
		Login updatedLogin = loginDAO.getLogin("renu");
		assertEquals(updatedLogin.getPassword(), "renuChanged");
	}
}
