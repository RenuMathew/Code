package com.npu.hw4.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.npu.hw4.domain.Login;

public class LoginRowMapper implements RowMapper<Login> {

	public Login mapRow(ResultSet resultSet, int row) throws SQLException {
		Login login = new Login();
		login.setId(resultSet.getInt("id"));
		login.setUserName(resultSet.getString("userName"));
		login.setPassword(resultSet.getString("password"));
		return login;
	}

}
