package com.npu.hw4.services;

import com.npu.hw4.domain.Login;

public interface LoginService {
	Login findLoginByUserName(String userName);
	void updateLogin(Login login);
	void createNewLogin(Login login);
	void deleteExistingLogin(Login login);
	

}
