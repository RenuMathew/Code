package com.npu.hw4.dao;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import com.npu.hw4.domain.Login;

@Repository("loginDao")
public class LoginDAOImpl implements LoginDAO {
	
	@Autowired
	@Qualifier("dataSource")
	private DataSource dataSource;
	
	private JdbcTemplate jdbcTemplate;
	private NamedParameterJdbcTemplate namedTemplate;
	private SimpleJdbcInsert jdbcInsert;
	private LoginRowMapper loginRowMapper;
	
	@PostConstruct
	public void setup() {
		jdbcTemplate = new JdbcTemplate(dataSource);
		namedTemplate = new NamedParameterJdbcTemplate(dataSource);
		jdbcInsert = new SimpleJdbcInsert(dataSource)
							.withTableName("login")
							.usingGeneratedKeyColumns("id");
		loginRowMapper = new LoginRowMapper();

	}
	
	public List<Login> getAllUsers() {
		String sql = "select * from login";
		List<Login> allUsers = jdbcTemplate.query(sql, loginRowMapper);
		return allUsers;
	}
	public void insertLogin(Login login) {
		SqlParameterSource params = new BeanPropertySqlParameterSource(login);
		Number newId = jdbcInsert.executeAndReturnKey(params);
  		login.setId(newId.intValue());
	}
	
	public Login getLogin(String userName) {
		String sql = "select * from login where userName=?";
		Login login = jdbcTemplate.queryForObject(sql, loginRowMapper, userName);
		return login;
	}
	
	public int updateLogin(Login login) {
		String sql = "update login set password=:password where userName=:userName";
		MapSqlParameterSource params;
		int rowsAffected;
		params = new MapSqlParameterSource("userName", login.getUserName());
		params.addValue("password", login.getPassword());
		rowsAffected = namedTemplate.update(sql, params);
		return rowsAffected;
	}
	
	public int deleteLogin(Login login) {
		String sql = "delete from login where userName=:userName";
		MapSqlParameterSource params;
		int rowsAffected;
		params = new MapSqlParameterSource("userName", login.getUserName());
		params.addValue("password", login.getPassword());
		rowsAffected = namedTemplate.update(sql, params);
		return rowsAffected;
	}
	

}
