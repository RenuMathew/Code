package com.npu.hw4.dao;

import java.util.List;

import com.npu.hw4.domain.Item;

public interface ItemDAO {
	
	void createItem(Item product);
	List<Item> getAllItems();
	Item getItemByName(String name);
	int updateItem(Item item);
	int deleteItem(Item item);

}
