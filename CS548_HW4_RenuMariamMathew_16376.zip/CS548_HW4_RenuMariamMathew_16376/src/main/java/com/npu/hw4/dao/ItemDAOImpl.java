package com.npu.hw4.dao;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import com.npu.hw4.domain.Item;

@Repository("itemDao")
public class ItemDAOImpl implements ItemDAO {
	
	@Autowired
	@Qualifier("dataSource")
	private DataSource dataSource;
	
	private JdbcTemplate jdbcTemplate;
	private NamedParameterJdbcTemplate namedTemplate;
	private SimpleJdbcInsert jdbcInsert;
	private ItemRowMapper itemRowMapper;
	
	@PostConstruct
	public void setup() {
		jdbcTemplate = new JdbcTemplate(dataSource);
		namedTemplate = new NamedParameterJdbcTemplate(dataSource);
		jdbcInsert = new SimpleJdbcInsert(dataSource)
							.withTableName("item")
							.usingGeneratedKeyColumns("id");
		itemRowMapper = new ItemRowMapper();

	}
	
	public void createItem(Item item) {
		SqlParameterSource params = new BeanPropertySqlParameterSource(item);
		Number newId = jdbcInsert.executeAndReturnKey(params);
		item.setId(newId.intValue());
	}
	
	public List<Item> getAllItems() {
		String sql = "select * from item";
		List<Item> items = jdbcTemplate.query(sql, itemRowMapper);
		return items;
	}
	
	public Item getItemByName(String name) {
		String sql = "select * from item where itemName=?";
		Item item = jdbcTemplate.queryForObject(sql, itemRowMapper, name);
		return item;
	}
	
	public int updateItem(Item item) {
		String sql = "update item set quantity=:quantity where id=:id";
		MapSqlParameterSource params;
		int rowsAffected;
		params = new MapSqlParameterSource("id", item.getId());
		params.addValue("quantity", item.getQuantity());
		rowsAffected = namedTemplate.update(sql, params);
		return rowsAffected;
	}
	
	public int deleteItem(Item item) {
		String sql = "delete from item where id=:id";
		MapSqlParameterSource params;
		int rowsAffected;
		params = new MapSqlParameterSource("id", item.getId());
		rowsAffected = namedTemplate.update(sql, params);
		return rowsAffected;
	}
	
}
