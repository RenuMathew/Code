package com.npu.hw4.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.npu.hw4.dao.LoginDAO;
import com.npu.hw4.domain.Login;

@Service("loginService")
@Transactional(readOnly=true)
public class LoginServiceImpl implements LoginService{
	
	@Autowired
	private LoginDAO loginDao;
	
	public Login findLoginByUserName(String userName) {
		Login login = loginDao.getLogin(userName);
		return login;
	}
	
	@Transactional(readOnly=false)
	public void updateLogin(Login login) {
		loginDao.updateLogin(login);
	}
	
	@Transactional(readOnly=false)
	public void createNewLogin(Login login) {
		loginDao.insertLogin(login);
	}
	
	@Transactional(readOnly=false)
	public void deleteExistingLogin(Login login) {
		loginDao.deleteLogin(login);
	}
	
}
