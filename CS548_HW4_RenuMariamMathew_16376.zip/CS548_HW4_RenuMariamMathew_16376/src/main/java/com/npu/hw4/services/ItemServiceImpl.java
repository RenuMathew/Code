package com.npu.hw4.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.npu.hw4.dao.ItemDAO;
import com.npu.hw4.domain.Item;

@Service("itemService")
@Transactional(readOnly=true)
public class ItemServiceImpl implements ItemService {
	@Autowired
	private ItemDAO itemDao;
	
	public List<Item> findAllItems() {
		List<Item> allItems = itemDao.getAllItems();
		return allItems;
	}
	
	@Transactional(readOnly=false)
	public void updateItem(Item item) {
		itemDao.updateItem(item);
	}
	
	@Transactional(readOnly=false)
	public void createNewItem(Item item) {
		itemDao.createItem(item);
	}
	
	@Transactional(readOnly=false)
	public void deleteExistingItem(Item item) {
		itemDao.deleteItem(item);
	}

}
