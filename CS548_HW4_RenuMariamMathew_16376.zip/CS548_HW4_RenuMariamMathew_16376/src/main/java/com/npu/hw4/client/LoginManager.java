package com.npu.hw4.client;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.npu.hw4.domain.Login;
import com.npu.hw4.services.LoginService;

public class LoginManager {
	private static LoginService loginService;
	
	public static void main(String args[]) {
		AbstractApplicationContext container = new ClassPathXmlApplicationContext("service.xml");
		loginService = (LoginService) container.getBean("loginService");
		
	
		Login login = new Login ("npu", "REST");
		loginService.createNewLogin(login);
		Login rlogin = loginService.findLoginByUserName("npu");
		System.out.println("password: " + rlogin.getPassword());
		loginService.deleteExistingLogin(rlogin);
		
		container.close();
	}

}
