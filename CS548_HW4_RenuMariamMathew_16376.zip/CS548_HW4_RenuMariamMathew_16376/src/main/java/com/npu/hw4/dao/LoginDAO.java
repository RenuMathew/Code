package com.npu.hw4.dao;

import java.util.List;

import com.npu.hw4.domain.Login;

public interface LoginDAO {
	
	List<Login> getAllUsers();
	void insertLogin(Login login);
	Login getLogin(String userName);
	int updateLogin(Login login);
	int deleteLogin(Login login);
	
}
