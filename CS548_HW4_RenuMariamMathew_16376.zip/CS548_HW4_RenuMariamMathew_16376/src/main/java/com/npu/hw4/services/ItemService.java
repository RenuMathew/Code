package com.npu.hw4.services;

public interface ItemService {

}
