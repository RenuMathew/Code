package com.npu.hw4.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.npu.hw4.domain.Item;


public class ItemRowMapper implements RowMapper<Item> {

	public Item mapRow(ResultSet resultSet, int row) throws SQLException {
		Item prod = new Item();
		prod.setId(resultSet.getInt("id"));
		prod.setItemName(resultSet.getString("itemName"));
		prod.setPrice(resultSet.getDouble("price"));
		prod.setQuantity(resultSet.getInt("quantity"));
		return prod;
	}

}
