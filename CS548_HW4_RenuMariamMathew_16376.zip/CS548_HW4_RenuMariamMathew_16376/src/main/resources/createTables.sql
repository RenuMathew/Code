DROP DATABASE IF EXISTS cs548db;

CREATE DATABASE cs548db_Lab4;

USE cs548db_Lab4;

CREATE TABLE login 
 (
  id INT NOT NULL AUTO_INCREMENT,
  userName VARCHAR(50) NOT NULL, 
  password VARCHAR(50) NOT NULL,
  PRIMARY KEY(id)
 );
 
INSERT INTO login (userName, password) VALUES 
     ('renu', 'renu123'),
     ('renju', 'renuChanged');
     
CREATE TABLE item
 (
   id INT NOT NULL AUTO_INCREMENT,
   itemName VARCHAR(50) NOT NULL,
   price INT NOT NULL,
   quantity INT NOT NULL,
   PRIMARY KEY(id)
 );	
 
 INSERT INTO item (itemName, price, quantity) VALUES
    ('Algorithms', 9, 120),
    ('Coding in java', 42, 243),
    ('PHP', 34, 220);

     
