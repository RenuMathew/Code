package com.lab3.exception;

public class InsufficientQuantityException extends Exception
{

	public InsufficientQuantityException() {
		
		super();
	}
	public InsufficientQuantityException(String message) {
		
		super(message);
	}
	InsufficientQuantityException(Throwable cause)
	{
		super(cause);
	}
	InsufficientQuantityException(String message,Throwable cause)
	{
		super(message, cause);
	}
	InsufficientQuantityException(String message,Throwable cause,boolean enableSuppression,boolean writableStackTrace)
	{
		super(message,cause,enableSuppression,writableStackTrace);
	}
}
