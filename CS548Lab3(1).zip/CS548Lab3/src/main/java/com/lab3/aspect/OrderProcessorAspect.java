package com.lab3.aspect;


import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
@Aspect
public class OrderProcessorAspect {
	final static Logger logger = Logger.getLogger(OrderProcessorAspect.class);
	@Around("execution(* lab2.OrderProcessor.newOrder(..))")
	public Object dostopwatchingtiming(ProceedingJoinPoint method) throws Throwable
	{
		String msgprefix="total time taken to process new order is";
		long startime = System.nanoTime();
		String msg;
		Object returnvalue = method.proceed();
		
		long stopTime = System.nanoTime();
		long tot=startime-stopTime;
		double seconds = (double)tot/100000;
		msg="Method Signature "+method.getSignature()+ " "+msgprefix+":"+seconds+" seconds";
		logger.info(msg);
		return returnvalue;
	}

}