package com.lab3.aspect;

import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class TaxAspect 
{
	final static Logger logger = Logger.getLogger(TaxAspect.class);
	
	@Before("execution(* lab2.AccountingService.computeTax(..))")
	public void beforeComputeTax(JoinPoint joinPoint)
	{
		logger.info(joinPoint.getSignature().getName()+" is called");
		 
	}
	@AfterReturning(
			pointcut="execution(* lab2.AccountingService.computeTax(..))",
			returning="result")
	public void afterReturnComputeTax(JoinPoint joinPoint,Object result)
	{
		logger.info(joinPoint.getSignature().getName()+" is called");
		logger.info("Return value:"+result);
	}
	
	
}
