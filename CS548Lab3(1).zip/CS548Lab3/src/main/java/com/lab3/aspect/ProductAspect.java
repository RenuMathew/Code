package com.lab3.aspect;

import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;

@Aspect
public class ProductAspect 
{

	final static Logger logger=Logger.getLogger(ProductAspect.class);
	@AfterThrowing(
			pointcut="execution (* lab2.InventoryService.adjustInventory(..))",
			throwing="error")
	public void afterThrowing(JoinPoint joinPoint, Throwable error)
	{
		logger.info(joinPoint.getSignature().getName()+" Method is called");
		logger.info("It is throwing error:"+error);
	}
	
	@After("execution(* lab2.Order.addItem(..))")
	public void afteraddItem(JoinPoint joinPoint)
	{
		logger.info("Item is added");
	}
}
