package com.npu.lab3;

public interface TaxService {
	public double computeTax(Order order);
}
