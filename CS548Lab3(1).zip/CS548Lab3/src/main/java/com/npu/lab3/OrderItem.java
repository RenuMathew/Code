package com.npu.lab3;

public class OrderItem {

	private Product product;
	private int productQty;
	private double totalAmt;
	
	public OrderItem(Product product, int productQty){
		this.product = product;
		this.productQty = productQty;
		setTotalAmt(product.getPrice() * productQty);
	}
	
	public String toString(){
		StringBuilder sb = new StringBuilder();
		sb.append("Product Name: "+product.getName()+"\n");
		sb.append("Quantity: "+productQty+"\n");
		sb.append("Total Amount: "+totalAmt+"\n");
		return sb.toString();
	}
	
	public Product getProduct() {
		return product;
	}
	
	public void setProduct(Product product) {
		this.product = product;
	}
	
	public int getProductQty() {
		return productQty;
	}
	
	public void setProductQty(int productQty) {
		this.productQty = productQty;
	}

	public double getTotalAmt() {
		return totalAmt;
	}

	public void setTotalAmt(double totalAmt) {
		this.totalAmt = totalAmt;
	}
	
	
	
}
