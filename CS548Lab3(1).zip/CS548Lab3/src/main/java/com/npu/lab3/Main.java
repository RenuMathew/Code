package com.npu.lab3;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		try{
			Customer firstCustomer = new Customer("first", "CA", "fMail", "fMobile");
			Customer secondCustomer = new Customer("second", "SF", "sMail", "sMobile");
			@SuppressWarnings("resource")
			AbstractApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
			context.registerShutdownHook();
			OrderProcessor orderProcessor = (OrderProcessor)context.getBean("OrderProcessorBean");
			InventoryService inventoryService = (InventoryService) context.getBean("InventoryServiceBean");

			OrderItem firstOrderItem = new OrderItem(inventoryService.getProductList().get(0), 30);
			OrderItem secondOrderItem = new OrderItem(inventoryService.getProductList().get(0), 5);
			OrderItem thirdOderItem = new OrderItem(inventoryService.getProductList().get(1), 5);

			Order firstOrder = new Order();		
			firstOrder.addItem(firstOrderItem);
			//firstOrder.addItem(secondOrderItem);
			firstOrder.setCustomer(firstCustomer);
			firstOrder.setStatus("Pending");

			/*	Order secondOrder = new Order();	
			secondOrder.addItem(thirdOderItem);
			secondOrder.setCustomer(secondCustomer);
			secondOrder.setStatus("Pending");*/

			//inventoryService.printCurrentInventory();
			orderProcessor.newOrder(firstOrder);
			//inventoryService.printCurrentInventory();
			//orderProcessor.newOrder(secondOrder);
			//inventoryService.printCurrentInventory();

		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
