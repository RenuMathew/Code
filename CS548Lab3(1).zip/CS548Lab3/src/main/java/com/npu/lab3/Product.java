package com.npu.lab3;

public class Product {

	private String name;
	private String description;
	private double price;
	private int productQty;

	public Product(){

	}

	public Product(String name, String description, double price, int productQty){
		this.name = name;
		this.description = description;
		this.price = price;
		this.productQty = productQty;
	}

	public String toString(){
		StringBuilder sb = new StringBuilder();
		sb.append("Product Name: "+name+"\n");
		sb.append("Description: "+description+"\n");
		sb.append("Price: "+price+"\n");
		sb.append("Product Qty: "+productQty+"\n");
		return sb.toString();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getProductQty() {
		return productQty;
	}

	public void setProductQty(int productQty) {
		this.productQty = productQty;
	}


}
