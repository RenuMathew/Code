package com.npu.lab3;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import com.lab3.exception.InsufficientQuantityException;

public class OrderProcessor implements ApplicationContextAware {

	ApplicationContext context;
	
	public OrderProcessor() {
		
	}
	 private double getAccountingService(Order order){
		try{	
			TaxService salesTax = (TaxService)context.getBean("AccountingServiceBean");
			return salesTax.computeTax(order);
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	 }
	 
	 private void getInventoryService(Order order)throws InsufficientQuantityException{		
		 InventoryService inventoryService = (InventoryService) context.getBean("InventoryServiceBean");
		inventoryService.adjustInventory(order);
	 }
	 
	 public void newOrder(Order order) throws InsufficientQuantityException{
		 double taxAmt = getAccountingService(order);
		 order.setTaxAmt(taxAmt);
		 double totalAmt = 0;
		 for(OrderItem orderItem : order.getOrderItemList()){
			totalAmt += (orderItem.getProductQty() * orderItem.getProduct().getPrice());
		 }
		 order.setTotalAmt(order.getTaxAmt() + totalAmt);
		 getInventoryService(order);
	 }
	public void setApplicationContext(ApplicationContext context) throws BeansException {
		this.context = context;		
	}
}
