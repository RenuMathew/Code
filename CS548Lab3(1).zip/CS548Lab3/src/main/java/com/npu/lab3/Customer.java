package com.npu.lab3;

public class Customer {

	private String name;
	private String state;
	private String mailId;
	private String mobile;
	
	public Customer(String name, String state, String mailId, String mobile){
		this.name = name;
		this.state = state;
		this.mobile = mobile;
		this.mailId = mailId;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	
}
