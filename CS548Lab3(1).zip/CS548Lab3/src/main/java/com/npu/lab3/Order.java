package com.npu.lab3;

import java.util.ArrayList;
import java.util.List;

public class Order {

	private Customer customer;
	private List<OrderItem> orderItemList;
	private String status;
	private double taxAmt;
	private double totalAmt;
	
	public Order(){
		orderItemList = new ArrayList<OrderItem>();
	}
		
	public void addItem(OrderItem item){
		 //checking the presence of order item within the order list
		 boolean flag = true;
		 int index = 0;
		 for(OrderItem orderItem : orderItemList){
			 if(orderItem.getProduct().getName().equals(item.getProduct().getName())){
				 flag = false;
				 OrderItem updateOrderItem = orderItemList.get(index);
				 updateOrderItem.setProductQty(updateOrderItem.getProductQty()+item.getProductQty());
				 orderItemList.set(index, updateOrderItem);
				 break;
			 }
			 index++;
		 }
		 if(flag)
			 orderItemList.add(item);
	 }
	 
	 public boolean removeProduct(Product prod){
		 int index = 0;
		 boolean flag = false;
		 for(OrderItem orderItem : orderItemList){
			 if(orderItem.getProduct().getName().equals(prod.getName())){
				 flag = true;
				 break;
			 }
			 index++;
		 }
		 if(flag){
			 orderItemList.remove(index);
			 return flag;
		 }
		 return flag;
	 }
	 
	public String toString(){
		StringBuilder sb = new StringBuilder();
		sb.append("Customer Name: "+customer.getName()+"\n");
		sb.append("Customer Order List,\n");
		for(OrderItem orderItem : orderItemList){
			sb.append(orderItem.toString());
		}
		sb.append("Tax Amount: "+taxAmt+"\n");
		sb.append("Status: "+status+"\n");
		return sb.toString();
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public List<OrderItem> getOrderItemList() {
		return orderItemList;
	}

	public void setOrderItemList(List<OrderItem> orderItemList) {
		this.orderItemList = orderItemList;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public double getTaxAmt() {
		return taxAmt;
	}

	public void setTaxAmt(double taxAmt) {
		this.taxAmt = taxAmt;
	}
	 
	public double getTotalAmt() {
		return totalAmt;
	}

	public void setTotalAmt(double totalAmt) {
		this.totalAmt = totalAmt;
	} 
}
