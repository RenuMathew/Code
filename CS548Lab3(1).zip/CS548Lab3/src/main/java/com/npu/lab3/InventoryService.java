package com.npu.lab3;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Required;

import com.lab3.exception.InsufficientQuantityException;


public class InventoryService {

	private List<Product> productList = new ArrayList<Product>();
	private List<Order> orderList = new ArrayList<Order>();
	
	public InventoryService() {
		
	}
	
	void updateProductQty(int newPrdQty, int index){
		Product updateProduct = productList.get(index);
		updateProduct.setProductQty(newPrdQty);
		productList.set(index, updateProduct);
	}
	
	public void adjustInventory(Order order)throws InsufficientQuantityException{
		boolean flag = true;
		outerLoop:for(OrderItem orderItem : order.getOrderItemList()){
			Product tempProduct = orderItem.getProduct();
			for(Product product : productList){
				if(product.getName().equals(tempProduct.getName())){
					if(orderItem.getProductQty() > product.getProductQty()){
						flag = false;
						break outerLoop;
					}
				}
			}
		}
		if(flag){
			for(OrderItem orderItem : order.getOrderItemList()){
				Product tempProduct = orderItem.getProduct();
				int index = 0;
				productLoop:for(Product product : productList){
					if(product.getName().equals(tempProduct.getName())){
						int newPrdQty = product.getProductQty() - orderItem.getProductQty();
						updateProductQty(newPrdQty, index);
						break productLoop;
					}
					index++;
				}
			}
			order.setStatus("SOLD");
		}else{
			order.setStatus("In-sufficient amount of product");
			//throw new InsufficientQuantityException("In-sufficient amount of product");
		}
		orderList.add(order);
	}
	
	void printCurrentInventory(){
		System.out.println("\n\nPrinting Inventory System,\n");
		System.out.println("Product List,");
		for(Product product : productList){
			System.out.println(product.toString());
		}
		System.out.println("Order list,");
		for(Order order : orderList){
			System.out.println(order.toString());
		}
	}
	
	public List<Product> getProductList() {
		return productList;
	}

	public void setProductList(List<Product> productList) {
		this.productList = productList;
	}

	public List<Order> getOrderList() {
		return orderList;
	}

	public void setOrderList(List<Order> orderList) {
		this.orderList = orderList;
	}
	
	
}
