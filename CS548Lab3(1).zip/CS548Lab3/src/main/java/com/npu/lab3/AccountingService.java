package com.npu.lab3;

import java.util.Map;

import org.aspectj.lang.annotation.AfterReturning;
import org.junit.After;

public class AccountingService implements TaxService {

	private Map<Object, Object> productMap;
	
	public double computeTax(Order order) throws ArithmeticException{
		String state = order.getCustomer().getState();
		double taxPercentage = Double.parseDouble(productMap.get(state).toString());
		double totalAmt = 0;
		for(OrderItem orderItem : order.getOrderItemList()){
			totalAmt += (orderItem.getProductQty() * orderItem.getProduct().getPrice());
		}
		double taxAmt = totalAmt - (totalAmt/taxPercentage);
		return taxAmt;
	}

	public Map<Object, Object> getProductMap() {
		return productMap;
	}

	public void setProductMap(Map<Object, Object> productMap) {
		this.productMap = productMap;
	}
	
	

}
