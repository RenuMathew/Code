package org.npu.courseapp;

public interface Service {
	
	String getMessage();

}
