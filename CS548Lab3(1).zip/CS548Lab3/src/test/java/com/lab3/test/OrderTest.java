package com.lab3.test;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.lab3.exception.InsufficientQuantityException;
import com.npu.lab3.InventoryService;
import com.npu.lab3.Order;
import com.npu.lab3.OrderItem;
import com.npu.lab3.OrderProcessor;
import com.npu.lab3.Product;

//@ContextConfiguration("classpath:ExampleConfigurationTests-context.xml")
@ContextConfiguration("classpath:/META-INF/spring/app-context.xml")

@RunWith(SpringJUnit4ClassRunner.class)
public class OrderTest {

	private Order order;
	private AbstractApplicationContext context;
	private InventoryService inventoryServiceBean;
	private OrderProcessor orderProcessor;
	@Before
	public void setUp(){
		order = new Order();
		context = new ClassPathXmlApplicationContext("spring.xml");
		inventoryServiceBean = (InventoryService)context.getBean("InventoryServiceBean"); 
		 orderProcessor = (OrderProcessor)context.getBean("OrderProcessorBean");
	}
	
	@Test(expected=InsufficientQuantityException.class)
	public void testAddItem() throws InsufficientQuantityException{

		List<Product> productList = inventoryServiceBean.getProductList();
		Product firstProduct = productList.get(0);
		assertEquals("firstProduct",firstProduct.getName());
		Product secondProduct = productList.get(1);
		assertEquals(10,secondProduct.getProductQty());

		//add first item
		OrderItem item = new OrderItem(secondProduct,1);
		order.addItem(item);
		
		//add second item
		item = new OrderItem(secondProduct,30);
		order.addItem(item);
		
		//add third item
		item = new OrderItem(secondProduct,1);
		order.addItem(item);
		
		//add fourth item
		item = new OrderItem(secondProduct,1);
		order.addItem(item);
		
		List<OrderItem> orderItemList = order.getOrderItemList();
		assertEquals(1,orderItemList.size());
		
		OrderItem orderItem = orderItemList.get(0);
		assertEquals("Product count should be 4",4,orderItem.getProductQty());
		orderProcessor.newOrder(order);
	}

	@Test
	public void testRemoveProduct(){
		List<Product> productList = inventoryServiceBean.getProductList();
		Product firstProduct = productList.get(0);
		boolean flag = order.removeProduct(firstProduct);
		assertFalse(flag); 
		OrderItem item = new OrderItem(firstProduct,1);
		order.addItem(item);
		flag = order.removeProduct(firstProduct);
		assertTrue(flag);
	}
	
	@Test
	public void testInventoryQntyCheck(){
		List<Product> productList = inventoryServiceBean.getProductList();
		Product firstProduct = productList.get(0);
		Product secondProduct = productList.get(1);
		//System.out.println(firstProduct.getProductQty());
		OrderItem item = new OrderItem(firstProduct,10);
		
		// available quantity is 28 and ordered quantity 10
		assertTrue(
				"Ordered product quanity should not exceed the available Inventory product quantity",
				item.getProductQty() <= firstProduct.getProductQty());
		order.addItem(item);
		
		item = new OrderItem(secondProduct,15);
		
		// available quantity is 10 and ordered quantity 15
		assertFalse(
				"Ordered product quanity should not exceed the available Inventory product quantity",
				item.getProductQty() <= secondProduct.getProductQty());
		order.addItem(item);
	}
}
