package com.lab3.test;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lab3.exception.InsufficientQuantityException;
import com.npu.lab3.Customer;
import com.npu.lab3.InventoryService;
import com.npu.lab3.Order;
import com.npu.lab3.OrderItem;
import com.npu.lab3.OrderProcessor;
import com.npu.lab3.Product;

public class InventoryServiceTest {
	
	private Order order;
	private AbstractApplicationContext context;
	private InventoryService inventoryServiceBean;
	private OrderProcessor orderProcessor;
	
	@Before
	public void setUp(){
		order = new Order();
		context = new ClassPathXmlApplicationContext("spring.xml");
		inventoryServiceBean = (InventoryService)context.getBean("InventoryServiceBean");
		orderProcessor =  (OrderProcessor)context.getBean("OrderProcessorBean");
	}
	
	@Test(expected=InsufficientQuantityException.class)
	public void testAdjustInventoryNegative()throws InsufficientQuantityException{
		Customer firstCustomer = new Customer("first", "CA", "fMail", "fMobile");
		
		List<Product> productList = inventoryServiceBean.getProductList();
		Product firstProduct = productList.get(0);
		Product secondProduct = productList.get(1);

		//ordered firstProduct with count 30
		OrderItem item = new OrderItem(firstProduct,30);
		order.setCustomer(firstCustomer);
		order.addItem(item);
		orderProcessor.newOrder(order);
		
		//available product count is 28 and placed order count 30
		assertEquals("In-sufficient amount of product",order.getStatus());
	}
	
	@Test
	public void testAdjustInventoryPositive()throws InsufficientQuantityException{
		Customer firstCustomer = new Customer("first", "CA", "fMail", "fMobile");
		List<Product> productList = inventoryServiceBean.getProductList();
		Product product = inventoryServiceBean.getProductList().get(0);
		
		//Initially first product count is 28
		assertEquals(28,product.getProductQty());
		Product firstProduct = productList.get(0);

		//ordered firstProduct with count 12
		OrderItem item = new OrderItem(firstProduct,12);
		order.setCustomer(firstCustomer);
		order.addItem(item);
		orderProcessor.newOrder(order);
		//available product count is 28 and placed order count 12
		assertEquals("SOLD",order.getStatus());		
		
		//Initially first product count is 28 and ordered 12, remaining product count is 16
		assertEquals(16,product.getProductQty());
	}
}
