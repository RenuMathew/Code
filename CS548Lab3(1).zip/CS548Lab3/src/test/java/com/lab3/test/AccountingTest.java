package com.lab3.test;

import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.npu.lab3.AccountingService;
import com.npu.lab3.Customer;
import com.npu.lab3.InventoryService;
import com.npu.lab3.Order;
import com.npu.lab3.OrderItem;
import com.npu.lab3.Product;
import com.npu.lab3.TaxService;

public class AccountingTest 
{
	@Before
	public void setUp(){
		
	}
	@Test(expected=ArithmeticException.class)
	public void computeTax()
	{
		@SuppressWarnings("resource")
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		
		Order order=new Order();
		InventoryService inventoryService=(InventoryService) context.getBean("InventoryServiceBean");
		List<Product> products=inventoryService.getProductList();
		
		Customer firstCustomer = new Customer("first", "CA", "fMail", "fMobile");
		
		OrderItem orderItem=new OrderItem(products.get(0), 2);
		order.addItem(orderItem);
		order.setCustomer(firstCustomer);
		order.setStatus("pending");
		
		TaxService taxService=(AccountingService)context.getBean("AccountingServiceBean");
		
		Assert.assertEquals("Tax is 0.0 for state:"+firstCustomer.getState(),0.0, taxService.computeTax(order));
		
	}
}
